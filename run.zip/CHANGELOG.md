# Changelog

# 0.0.1 - Lección 1: La primera aplicación Flask (03/12/2018)

- Versión inicial de la aplicación
